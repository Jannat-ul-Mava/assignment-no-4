package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class game_history extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage HistoryStage) {
        CustomTitleBar customTitleBar = new CustomTitleBar(HistoryStage);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #fffcf6; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #333883; -fx-border-width: 5px; -fx-padding: 20px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(550);

        // Back Button
        Button backButton = new Button();
        ImageView arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(40);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton,"/com/example/mind_marathon_project/back_button.png");
        backButton.setStyle("-fx-background-color: #fffcf6; -fx-border-color: #fffcf6;");
        backButton.setOnAction(e -> {
            try {
                new Achievements_page().start(new Stage());
                HistoryStage.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        // Title
        ImageView historyTitle = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/history_button.png").toExternalForm()));
        historyTitle.setFitHeight(150);
        historyTitle.setFitWidth(350);

        HBox headerBox = new HBox(backButton, historyTitle);
        headerBox.setAlignment(Pos.TOP_CENTER);
        headerBox.setSpacing(30);

        // Record Box for dynamic content
        HBox recordBox = new HBox(50); // Spacing between columns
        recordBox.setAlignment(Pos.CENTER);

        // Read file data
        StringBuilder dates = new StringBuilder();
        StringBuilder scores = new StringBuilder();
        StringBuilder statuses = new StringBuilder();

        try (FileReader reader = new FileReader("history.txt");
             Scanner scanner = new Scanner(reader)) {

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.contains("Date:") && line.contains("Score:") && line.contains("Status:")) {
                    String date = "N/A";
                    String score = "0";
                    String status = "Unknown";

                    String[] parts = line.split("\\|");
                    for (String part : parts) {
                        if (part.contains("Date:")) {
                            date = part.replace("Date:", "").trim();
                        } else if (part.contains("Score:")) {
                            score = part.replace("Score:", "").trim();
                        } else if (part.contains("Status:")) {
                            status = part.replace("Status:", "").trim();
                        }
                    }

                    dates.append(date).append("\n");
                    scores.append(score).append("\n");
                    statuses.append(status).append("\n");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading file: " + e.getMessage());
        }

        // Add record columns
        recordBox.getChildren().addAll(
                createRecordColumn("Dates", dates.toString().trim()),
                createRecordColumn("Scores", scores.toString().trim()),
                createRecordColumn("Statuses", statuses.toString().trim())
        );

        // Add everything to the cardPane
        cardPane.getChildren().addAll(headerBox, recordBox);
        root.setCenter(cardPane);

        Scene scene = new Scene(root, 800, 600);
        HistoryStage.initStyle(StageStyle.UNDECORATED);
        HistoryStage.setMaximized(true);
        HistoryStage.setScene(scene);
        HistoryStage.show();
    }

    private VBox createRecordColumn(String header, String values) {
        // Header Button
        Button headerButton = new Button(header);
        headerButton.setStyle("-fx-background-color: linear-gradient(to bottom, #66ccff, #0033cc); -fx-text-fill: white; -fx-font-size: 16px;");

        // Content Box with dynamic labels
        VBox contentBox = new VBox(10);
        contentBox.setAlignment(Pos.CENTER_LEFT);
        contentBox.setPadding(new Insets(10));
        for (String value : values.split("\n")) {
            Label recordLabel = new Label(value);
            recordLabel.setStyle("-fx-font-size: 14px;");
            contentBox.getChildren().add(recordLabel);
        }

        // ScrollPane wrapping the content
        ScrollPane scrollPane = new ScrollPane(contentBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(200);
        scrollPane.setStyle("-fx-background: #f5f5f5; -fx-border-color: lightgray;");

        // Column Box
        VBox columnBox = new VBox(20);
        columnBox.setPrefWidth(200);
        columnBox.setAlignment(Pos.CENTER);
        columnBox.setStyle("-fx-border-color: lightgray; -fx-border-width: 2px;");
        columnBox.getChildren().addAll(headerButton, scrollPane);

        return columnBox;
    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        // Play sound effect
        // AudioClip clickSound = new AudioClip(getClass().getResource(soundFile).toExternalForm());

        // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });

        // Play sound on click
        //    button.setOnMouseClicked(e -> clickSound.play());
    }

}