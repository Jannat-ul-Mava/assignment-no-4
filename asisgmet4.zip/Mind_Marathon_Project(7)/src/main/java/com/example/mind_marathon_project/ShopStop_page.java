package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ShopStop_page extends Application {

    @Override
    public void start(Stage stage6) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage6);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #ffffff;");
        root.setTop(customTitleBar);

        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #fffcf6; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ff7bac; " +
                "-fx-padding: 0px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(590);

        Button backButton = new Button();

        ImageView arrowImageView = loadImage("/com/example/mind_marathon_project/arrow.png");
        arrowImageView.setFitHeight(50);
        arrowImageView.setFitWidth(50);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: #fffcf6; -fx-border-color: #fffcf6;");

        HBox titleBar = new HBox();
        titleBar.setStyle("-fx-background-color: #f15363;-fx-background-radius: 20px;-fx-border-radius: 20px;-fx-border-color:#f15363;-fx-border-width: 2px;-fx-padding: 5,0,5,0");
        titleBar.setSpacing(10);
        titleBar.setAlignment(Pos.CENTER);
        titleBar.setMaxWidth(200);
        titleBar.setMaxHeight(100);

        Label headerLabel = new Label("Shop Stop");
        headerLabel.setStyle("-fx-text-fill: #ffffff;-fx-font-weight: bold;-fx-font-family: 'Comic Sans MS';-fx-font-size: 24px");
        headerLabel.setAlignment(Pos.CENTER);

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);

        ImageView money = loadImage("/com/example/mind_marathon_project/money.png");
        money.setFitWidth(30);
        money.setFitHeight(30);
        titleBar.getChildren().addAll(headerLabel, money);

        HBox headerBox = new HBox(backButton,titleBar);
        headerBox.setSpacing(140);
        // headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(0, 0, 10, 0));

        Region spacer1 = new Region();
        HBox.setHgrow(spacer1, Priority.ALWAYS);

        // Create a Label for displaying purchase success message
        Label purchaseMessage = new Label();
        purchaseMessage.setStyle("-fx-text-fill: #3d3939; -fx-font-weight: bold;");
        purchaseMessage.setAlignment(Pos.CENTER);

        ImageView shop;
        try{
            shop=new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/shop_base.png")));
        }
        catch(NullPointerException e){
            throw e;
        }
        shop.setFitHeight(480);
        shop.setFitWidth(400);

        HBox hbox1 = new HBox();
        hbox1.setAlignment(Pos.CENTER);
        hbox1.setSpacing(20);

        ImageView hintlogo = loadImage("/com/example/mind_marathon_project/hint_image.png");
        hintlogo.setFitHeight(90);
        hintlogo.setFitWidth(150);

        Button buyButtonhint = new Button("BUY");

        buyButtonhint.setStyle("-fx-background-color: #fffcf6;-fx-border-color:#b78fd6;-fx-border-width: 3px;-fx-border-radius: 18px;-fx-text-fill: #3d3939;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 10");
        addButtonEffects(buyButtonhint, "/com/example/mind_marathon_project/main_button.mp3");


        hbox1.getChildren().addAll(hintlogo, buyButtonhint);

        HBox hbox2 = new HBox();
        hbox2.setAlignment(Pos.CENTER);
        hbox2.setSpacing(20);

        ImageView lifelogo = loadImage("/com/example/mind_marathon_project/life_image.png");
        lifelogo.setFitHeight(80);
        lifelogo.setFitWidth(150);

        Button buyButtonlife = new Button("BUY");
        buyButtonlife.setStyle("-fx-background-color: #fffcf6;-fx-border-color:#b78fd6;-fx-border-width: 3px;-fx-border-radius: 18px;-fx-text-fill: #3d3939;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 10");
        addButtonEffects(buyButtonlife, "/com/example/mind_marathon_project/main_button.mp3");
        buyButtonlife.setOnAction(e -> {
            // Show a success message for Life purchase
            purchaseMessage.setText("You have successfully purchased a Life!");
            purchaseMessage.setStyle("-fx-text-fill: White; -fx-font-weight: bold; -fx-font-size: 20px;");
        });
        String coin1 = "0";
        String heart1= "0";

        try {
            FileReader reader = new FileReader("history.txt");
            Scanner scanner = new Scanner(reader);
            String lastEntery="";
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.contains("Coins:") && line.contains("Lives")){
                    lastEntery =line;
                    // coin1 = line.split("|")[1].trim();
                } //else if (line.startsWith("Lives")) {
                //heart1 = line.split("|")[1].trim();

            }


            scanner.close();
            reader.close();
            if(!lastEntery.isEmpty()){
                String[] parts = lastEntery.split("\\|");
                for(String part : parts){
                    if(part.contains("Coins:")){
                        coin1 =  part.replaceAll("[^0-9]", "");


                    } else if (part.contains("Lives")) {
                        heart1 = part.replaceAll("[^0-9]", "");


                    }
                }

            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        hbox2.getChildren().addAll(lifelogo, buyButtonlife);
        ImageView coin=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/coins_button.png").toExternalForm()));
        coin.setFitHeight(40);
        coin.setFitWidth(45);
        Label coinValue=new Label(coin1);
        coinValue.setAlignment(Pos.CENTER);
        coinValue.setStyle("-fx-text-fill: #1a1717;");
        HBox coinBox=new HBox();
        coinBox.getChildren().addAll(coin,coinValue);
        coinBox.setAlignment(Pos.CENTER);

        ImageView heart=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/life_button.png").toExternalForm()));
        heart.setFitHeight(35);
        heart.setFitWidth(35);
        Label heartValue=new Label(heart1);
        heartValue.setAlignment(Pos.CENTER);
        heartValue.setStyle("-fx-text-fill: #1a1414;");
        HBox heartBox=new HBox();
        heartBox.setSpacing(4);
        heartBox.getChildren().addAll(heart,heartValue);
        heartBox.setAlignment(Pos.CENTER);

        HBox sideBox=new HBox();
        sideBox.setAlignment(
                Pos.CENTER
        );
        sideBox.setSpacing(80);
        sideBox.setTranslateY(35);
        sideBox.getChildren().addAll(coinBox,heartBox);

        HBox headerBox1 = new HBox(sideBox);
        headerBox1.setAlignment(Pos.BOTTOM_CENTER);// Add some spacing after the label for better layout
        headerBox1.setPadding(new Insets(0, 0, 0, 0));

        Button okbutton = new Button("  OK  ");
        okbutton.setStyle("-fx-background-radius:20px;-fx-background-size: 100px;-fx-background-color: #f15363;-fx-border-color: #f59eb7;-fx-border-radius: 20px;-fx-border-width: 2;-fx-font-size: 14px; -fx-text-fill: #ffffff;-fx-font-family:'Comic Sans MS' ;-fx-font-weight: bold;-fx-padding: 10,10,10,10;");
        try {
            addButtonEffects(okbutton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }
        okbutton.setOnAction(e->{
            try {
                new Menu_page().start(new Stage());
                stage6.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });

        Region spacer3 = new Region();
        spacer3.setMaxSize(30,50);
        VBox.setVgrow(spacer3, Priority.ALWAYS);
        Region spacer4 = new Region();
        spacer4.setMaxSize(0,30);
        VBox.setVgrow(spacer4, Priority.ALWAYS);
        Region spacer5 = new Region();
        spacer5.setMaxSize(0,60);
        VBox.setVgrow(spacer5, Priority.ALWAYS);

        VBox baseOfShop=new VBox();
        baseOfShop.setAlignment(Pos.CENTER);
        baseOfShop.getChildren().addAll(spacer3,headerBox1,spacer5,hbox1,hbox2,spacer4,okbutton);
        StackPane base=new StackPane();
        base.getChildren().addAll(shop,baseOfShop);

        VBox vbox = new VBox(1, headerBox, base, purchaseMessage);
        vbox.setStyle("-fx-alignment: center; -fx-padding: 1;");
        vbox.setAlignment(Pos.CENTER);

        cardPane.getChildren().addAll(vbox);

        root.setCenter(cardPane);

        backButton.setOnAction(e -> {
            try {
                new Menu_page().start(new Stage());
                stage6.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        Scene scene = new Scene(root, 800, 600);
        stage6.initStyle(StageStyle.UNDECORATED);
        stage6.setMaximized(true);
        stage6.setScene(scene);
        stage6.show();
    }

    // Helper method to load images
    private ImageView loadImage(String path) {
        try {
            return new ImageView(new Image(getClass().getResourceAsStream(path)));
        } catch (NullPointerException e) {
            System.out.println("Image not found: " + path);
            return new ImageView();
        }
    }

    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        // Add hover effects
        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
