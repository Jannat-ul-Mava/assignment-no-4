package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.*;
import java.util.Scanner;

public class Edit_page extends Application {
    @Override
    public void start(Stage stage9) {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage9);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);

        Button backButton = new Button();
        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        } catch (NullPointerException e) {
            System.err.println("Error loading arrow image: " + e.getMessage());
            return;
        }
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(40);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_RIGHT);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        String coin1 = "0";
        String heart1= "0";

        try {
            FileReader reader = new FileReader("history.txt");
            Scanner scanner = new Scanner(reader);
            String lastEntery="";
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.contains("Coins:") && line.contains("Lives")){
                    lastEntery =line;
                    // coin1 = line.split("|")[1].trim();
                } //else if (line.startsWith("Lives")) {
                //heart1 = line.split("|")[1].trim();

            }


            scanner.close();
            reader.close();
            if(!lastEntery.isEmpty()){
                String[] parts = lastEntery.split("\\|");
                for(String part : parts){
                    if(part.contains("Coins:")){
                        coin1 =  part.replaceAll("[^0-9]", "");


                    } else if (part.contains("Lives")) {
                        heart1 = part.replaceAll("[^0-9]", "");


                    }
                }

            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ImageView coin = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/coins_button.png").toExternalForm()));
        coin.setFitHeight(30);
        coin.setFitWidth(35);
        Label coinValue = new Label(coin1);
        coinValue.setAlignment(Pos.CENTER);
        coinValue.setStyle("-fx-text-fill: #ffffff;");
        HBox coinBox = new HBox(coin, coinValue);
        coinBox.setAlignment(Pos.CENTER_RIGHT);

        ImageView heart = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/life_button.png").toExternalForm()));
        heart.setFitHeight(25);
        heart.setFitWidth(25);
        Label heartValue = new Label(heart1);
        heartValue.setAlignment(Pos.CENTER);
        heartValue.setStyle("-fx-text-fill: #fcfcfc;");
        HBox heartBox = new HBox(4, heart, heartValue);
        heartBox.setAlignment(Pos.CENTER_RIGHT);

        HBox sideBox = new HBox(10, coinBox, heartBox);
        sideBox.setAlignment(Pos.CENTER_RIGHT);

        HBox headerBox2 = new HBox(400, backButton, sideBox);
        headerBox2.setAlignment(Pos.CENTER_LEFT);
        headerBox2.setPadding(new Insets(0, 0, 10, 0));

        Label headerLabel = new Label("Edit Information");
        headerLabel.setStyle("-fx-background-radius:20px;-fx-background-size: 20px;-fx-background-color: #fff4f4;-fx-border-color: #06d2ec;" +
                "-fx-border-radius: 20px;-fx-border-width: 2;-fx-font-size: 24px; -fx-text-fill: #1b548d;-fx-font-family:'Comic Sans MS';" +
                "-fx-font-weight: bold;-fx-padding: 10,10,10,10;");
        headerLabel.setAlignment(Pos.TOP_CENTER);

        HBox headerBox1 = new HBox(headerLabel);
        headerBox1.setAlignment(Pos.TOP_CENTER);
        headerBox1.setSpacing(10);

        VBox headerBox = new VBox(headerBox2, headerBox1);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setPadding(new Insets(0, 0, 10, 0));

        VBox fields = new VBox(30);
        fields.setAlignment(Pos.CENTER);
        String name1="" ;
        String age1="";
        String password1="";

        try (FileReader fileReader = new FileReader("user_data.txt");
             Scanner scanner = new Scanner(fileReader)) {


            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();


                if (line.startsWith("Name:")) {
                    name1 = line.substring(5).trim();
                }


                if (line.startsWith("Age:")) {
                    age1 = line.substring(4).trim();
                }
                if (line.startsWith("Password:")) {
                    password1 = line.substring(4).trim();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        TextField nameField = new TextField(name1);
        styleTextField(nameField);

        TextField ageField = new TextField(age1);
        styleTextField(ageField);

        TextField passwordField = new TextField(password1);
        styleTextField(passwordField);

        fields.getChildren().addAll(nameField, ageField, passwordField);

        Button okButton = new Button("  OK  ");
        okButton.setStyle("-fx-background-radius:20px;-fx-background-size: 100px;-fx-background-color: #ffe47a;" +
                "-fx-border-color: #c0981b;-fx-border-radius: 20px;-fx-border-width: 2;-fx-font-size: 14px; -fx-text-fill: #3d3939;" +
                "-fx-font-family:'Comic Sans MS' ;-fx-font-weight: bold;-fx-padding: 10,10,10,10;");
        addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");

        okButton.setOnAction(event -> handleOkButton(nameField, ageField, passwordField));

        VBox cardPane = new VBox(40, headerBox, fields, okButton);
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #1b548d; -fx-background-radius: 20px; -fx-border-radius: 20px; -fx-border-color: #ff7bac; -fx-padding: 20px;");
        cardPane.setMaxWidth(600);
        cardPane.setMaxHeight(500);

        root.setCenter(cardPane);

        backButton.setOnAction(e -> {
            try {
                new Menu_page().start(new Stage());
                stage9.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        });
        okButton.setOnAction(event -> {
            String name = nameField.getText().trim();
            String password = passwordField.getText().trim();
            String age = ageField.getText().trim();

            if (name.isEmpty() || password.isEmpty() || age.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields are required.");
                return;
            }

            try {

                StringBuilder newUserData = new StringBuilder();
                newUserData.append("Name: ").append(name).append("\n");
                newUserData.append("Password: ").append(password).append("\n");
                newUserData.append("Age: ").append(age).append("\n");


                File file = new File("user_data.txt");
                try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                    writer.write(newUserData.toString());
                }

                showAlert(Alert.AlertType.INFORMATION, "Success", "User details updated successfully.");
            } catch (IOException e) {
                showAlert(Alert.AlertType.ERROR, "File Error", "An error occurred while updating the user data file.");
                e.printStackTrace();
            }
        });


        Scene scene = new Scene(root, 800, 600);
        stage9.initStyle(StageStyle.UNDECORATED);
        stage9.setMaximized(true);
        stage9.setScene(scene);
        stage9.show();
    }

    private void styleTextField(TextField textField) {
        textField.setMaxWidth(200);
        textField.setStyle("-fx-background-color: #fcfcfc;-fx-background-radius: 10px;-fx-border-width: 2;" +
                "-fx-border-color: #06d2ec; -fx-border-radius: 10px; -fx-text-fill: #4a4a4a;" +
                "-fx-font-family:'Comic Sans MS';-fx-padding: 10,5,10,5;");
    }

    private void handleOkButton(TextField nameField, TextField ageField, TextField passwordField) {
        String name = nameField.getText().trim();
        String password = passwordField.getText().trim();
        String age = ageField.getText().trim();
        if (name.isEmpty() || password.isEmpty() || age.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields are required.");
            return;
        }
        // Add your validation and file handling logic here.
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }

    private void goBackToMenu(Stage currentStage) {
        System.out.println("Back to Menu");
        currentStage.close();
        // Implement navigation to the menu page here.
    }

    public static void main(String[] args) {
        launch(args);
    }
}
