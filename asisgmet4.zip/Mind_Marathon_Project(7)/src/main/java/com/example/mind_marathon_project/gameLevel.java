package com.example.mind_marathon_project;

import com.example.mind_marathon_project.CustomTitleBar;
import javafx.animation.ScaleTransition;
import javafx.util.Duration;



import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
        import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class gameLevel extends Application {
    @Override
    public void start(Stage stage10) throws Exception {

        CustomTitleBar customTitleBar = new CustomTitleBar(stage10);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fffcf6;");
        root.setTop(customTitleBar);
        VBox cardPane = new VBox();
        cardPane.setAlignment(Pos.CENTER);
        cardPane.setStyle("-fx-background-color: #fcfcfc; " +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #252d62; " +
                "-fx-padding: 40px;");
        cardPane.setMaxWidth(850);
        cardPane.setMaxHeight(550);

        ImageView imageView;
        try{
            imageView= new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/mode_base.png").toExternalForm()));
        }catch (NullPointerException e){
            throw e;
        }
        imageView.setFitWidth(750);
        imageView.setFitHeight(500);
        HBox hBox = new HBox(imageView);
        hBox.setAlignment(Pos.CENTER);

        Button backButton = new Button();
        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/arrow.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        arrowImageView.setFitHeight(40);
        arrowImageView.setFitWidth(40);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
        // backButton.setOnAction(e -> goBackToMenu());

        VBox headerBox = new VBox(backButton);
        headerBox.setAlignment(Pos.TOP_LEFT);
        headerBox.setPadding(new Insets(0, 0, 10, 0));
        String coin1 = "0";
        String heart1= "0";

        try {
            FileReader reader = new FileReader("history.txt");
            Scanner scanner = new Scanner(reader);
            String lastEntery="";
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.contains("Coins:") && line.contains("Lives")){
                    lastEntery =line;
                    // coin1 = line.split("|")[1].trim();
                } //else if (line.startsWith("Lives")) {
                //heart1 = line.split("|")[1].trim();

            }


            scanner.close();
            reader.close();
            if(!lastEntery.isEmpty()){
                String[] parts = lastEntery.split("\\|");
                for(String part : parts){
                    if(part.contains("Coins:")){
                        coin1 =  part.replaceAll("[^0-9]", "");


                    } else if (part.contains("Lives")) {
                        heart1 = part.replaceAll("[^0-9]", "");


                    }
                }

            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        ImageView coin=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/coins_button.png").toExternalForm()));
        coin.setFitHeight(30);
        coin.setFitWidth(35);
        Label coinValue=new Label(coin1);
        coinValue.setAlignment(Pos.CENTER);
        coinValue.setStyle("-fx-text-fill: black;");
        HBox coinBox=new HBox();
        coinBox.getChildren().addAll(coin,coinValue);
        coinBox.setAlignment(Pos.TOP_RIGHT);

        ImageView heart=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/life_button.png").toExternalForm()));
        heart.setFitHeight(25);
        heart.setFitWidth(25);
        Label heartValue=new Label(heart1);
        heartValue.setAlignment(Pos.CENTER);
        heartValue.setStyle("-fx-text-fill: black;");
        HBox heartBox=new HBox();
        heartBox.setSpacing(4);
        heartBox.getChildren().addAll(heart,heartValue);
        heartBox.setAlignment(Pos.TOP_RIGHT);

        HBox sideBox=new HBox();
        sideBox.setAlignment(
                Pos.TOP_RIGHT
        );
        sideBox.setSpacing(10);
        sideBox.setPadding(new Insets(10, 10, 0, 0));
        sideBox.getChildren().addAll(coinBox,heartBox);

        HBox topBox=new HBox();
        topBox.setAlignment(Pos.TOP_CENTER);
        topBox.setSpacing(450);
        topBox.setTranslateY(60);
        topBox.getChildren().addAll(headerBox,sideBox);

        Button easyButton = new Button();
        ImageView easy;
        try{
            easy=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/easy.png").toExternalForm()));
        }
        catch (NullPointerException e){
            throw e;
        }
        easy.setFitHeight(200);
        easy.setFitWidth(205);
        easyButton.setStyle("-fx-background-color: transparent;-fx-border-color:transparent;");
        easyButton.setGraphic(easy);

        try {
            addButtonEffects(easyButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }

        Button mediumButton = new Button();
        ImageView medium;
        try{
            medium=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/medium.png").toExternalForm()));
        }
        catch (NullPointerException e){
            throw e;
        }
        medium.setFitHeight(200);
        medium.setFitWidth(205);
        mediumButton.setStyle("-fx-background-color: transparent;-fx-border-color:transparent;");
        mediumButton.setGraphic(medium);
        try {
            addButtonEffects(mediumButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }

        Button epicButton = new Button();
        ImageView epic;
        try{
            epic=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/epic.png").toExternalForm()));
        }
        catch (NullPointerException e){
            throw e;
        }
        epic.setFitHeight(200);
        epic.setFitWidth(205);
        epicButton.setStyle("-fx-background-color: transparent; -fx-border-color:transparent;");
        epicButton.setGraphic(epic);
        try {
            addButtonEffects(epicButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }

        HBox buttonBox = new HBox();
        buttonBox.getChildren().addAll(easyButton,mediumButton,epicButton);
        buttonBox.setStyle("-fx-background-color: transparent;-fx-border-color:transparent;");
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setMaxHeight(100);
        StackPane backgroundPane = new StackPane();
        backgroundPane.setPickOnBounds(false);
        backgroundPane.getChildren().addAll(hBox,topBox,buttonBox);

        cardPane.getChildren().addAll(backgroundPane);
        root.setCenter(cardPane);
        backButton.setOnAction(e->{

            try {
                new Interest_page().start(new Stage());
                stage10.close();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }

        });
        easyButton.setOnAction(e -> {
            new Question_page().start(new Stage());
            stage10.close();
        });

        mediumButton.setOnAction(e -> {
            new Question_page().start(new Stage());
            stage10.close();
        });

        epicButton.setOnAction(e -> {
            new Question_page().start(new Stage());
            stage10.close();
        });



        Scene scene = new Scene(root, 900, 600);
        stage10.initStyle(StageStyle.UNDECORATED);
        stage10.setMaximized(true);
        stage10.setScene(scene);
        stage10.show();


    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleUp = new ScaleTransition(Duration.millis(200), button);
        scaleUp.setFromX(1.0);
        scaleUp.setFromY(1.0);
        scaleUp.setToX(1.1);
        scaleUp.setToY(1.1);

        ScaleTransition scaleDown = new ScaleTransition(Duration.millis(200), button);
        scaleDown.setFromX(1.1);
        scaleDown.setFromY(1.1);
        scaleDown.setToX(1.0);
        scaleDown.setToY(1.0);

        button.setOnMouseEntered(e -> {
            scaleDown.stop(); // Stop the scale-down animation if running
            scaleUp.playFromStart(); // Start scaling up
        });

        button.setOnMouseExited(e -> {
            scaleUp.stop(); // Stop the scale-up animation if running
            scaleDown.playFromStart(); // Start scaling down
        });
    }


}