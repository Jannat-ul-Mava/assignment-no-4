package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class Result_page extends Application {
    int score=10;


    public void start(Stage stage11) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage11);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f1f5f6;");
        root.setTop(customTitleBar);

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #5eb090;" +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #3c6ca8; " +
                "-fx-padding: 20px;");
        vbox.setMaxWidth(600);
        vbox.setMaxHeight(500);

        ImageView login;
        try {
            login = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/score_pic.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        login.setFitWidth(190);
        login.setFitHeight(60);
        Button backButton = new Button();
        ImageView arrowImageView;
        try {
            arrowImageView = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/menu.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
backButton.setOnAction(event -> {
    try {
        new Menu_page().start(new Stage());
        stage11.close();
    } catch (Exception e) {
        throw new RuntimeException(e);
    }

});
        String coin1 = "0";
        String heart1= "0";

        try {
            FileReader reader = new FileReader("history.txt");
            Scanner scanner = new Scanner(reader);
            String lastEntery="";
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.contains("Coins:") && line.contains("Lives")){
                    lastEntery =line;
                    // coin1 = line.split("|")[1].trim();
                } //else if (line.startsWith("Lives")) {
                //heart1 = line.split("|")[1].trim();

            }


            scanner.close();
            reader.close();
            if(!lastEntery.isEmpty()){
                String[] parts = lastEntery.split("\\|");
                for(String part : parts){
                    if(part.contains("Coins:")){
                        coin1 =  part.replaceAll("[^0-9]", "");


                    } else if (part.contains("Lives")) {
                        heart1 = part.replaceAll("[^0-9]", "");


                    }
                }

            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        arrowImageView.setFitHeight(50);
        arrowImageView.setFitWidth(50);
        backButton.setGraphic(arrowImageView);
        addButtonEffects(backButton, "/com/example/mind_marathon_project/click_sound.mp3");
        backButton.setAlignment(Pos.TOP_LEFT);
        backButton.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");

        ImageView coin=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/coins_button.png").toExternalForm()));
        coin.setFitHeight(30);
        coin.setFitWidth(35);
        Label coinValue=new Label(coin1);
        coinValue.setAlignment(Pos.CENTER);
        coinValue.setStyle("-fx-text-fill: #fffdfd;");
        HBox coinBox=new HBox();
        coinBox.getChildren().addAll(coin,coinValue);
        coinBox.setAlignment(Pos.CENTER_RIGHT);

        ImageView heart=new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/life_button.png").toExternalForm()));
        heart.setFitHeight(25);
        heart.setFitWidth(25);
        Label heartValue=new Label(heart1);
        heartValue.setAlignment(Pos.CENTER);
        heartValue.setStyle("-fx-text-fill: #fffdfd;");
        HBox heartBox=new HBox();
        heartBox.setSpacing(4);
        heartBox.getChildren().addAll(heart,heartValue);
        heartBox.setAlignment(Pos.CENTER_RIGHT);

        HBox sideBox=new HBox();
        sideBox.setAlignment(
                Pos.CENTER_RIGHT
        );
        sideBox.setSpacing(10);
        sideBox.getChildren().addAll(coinBox,heartBox);

        HBox headerBox = new HBox(100,backButton,login,sideBox);
        headerBox.setAlignment(Pos.CENTER_LEFT);// Add some spacing after the label for better layout
        headerBox.setPadding(new Insets(0, 0, 10, 0));

        StackPane base=new StackPane();
        base.setAlignment(Pos.CENTER);
        String score1 = "0";
        String coin2= "0";
        //int totalcoins = 0;


        try {
            FileReader reader = new FileReader("history.txt");
            Scanner scanner = new Scanner(reader);
            String lastEntery="";
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if(line.contains("Coins:") && line.contains("Score:")){
                    lastEntery =line;
                    // coin1 = line.split("|")[1].trim();
                } //else if (line.startsWith("Lives")) {
                //heart1 = line.split("|")[1].trim();

            }


            scanner.close();
            reader.close();
            if(!lastEntery.isEmpty()){
                String[] parts = lastEntery.split("\\|");
                for(String part : parts){
                    if(part.contains("Coins:")){
                        coin2 =  part.replaceAll("[^0-9]", "");
                        //totalcoins += Integer.parseInt(coinString);


                    } else if (part.contains("Score")) {
                        score1 = part.replaceAll("[^0-9]", "");


                    }
                }

            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        HBox starsBox = new HBox(10);
        starsBox.setAlignment(Pos.CENTER);
        starsBox.setPadding(new Insets(20, 0, 10, 0));
        addStars(starsBox, score);

        ImageView picture;
        try {
            picture = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/result_background.png").toExternalForm()));
        } catch (NullPointerException e) {
            throw e;
        }
        picture.setFitWidth(450);
        picture.setFitHeight(400);

        HBox formFields = new HBox(picture);
        formFields.setAlignment(Pos.CENTER);
        formFields.setPadding(new Insets(10));

        ImageView trophyImage = new ImageView();
        setTrophyImage(trophyImage, score);
        trophyImage.setFitHeight(100);
        trophyImage.setFitWidth(300);







        Text scoreText = new Text(score1 + " / 100");
        scoreText.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        scoreText.setStyle("-fx-fill: #003366;");
        StackPane formContainer = new StackPane(trophyImage,scoreText);
        formContainer.setAlignment(Pos.CENTER);
        coinValue.setText(String.valueOf(coin2));
        heartValue.setText(String.valueOf(heart1));

        ImageView coinImage = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/coins_button.png").toExternalForm()));
        coinImage.setFitWidth(30);
        coinImage.setFitHeight(30);

        Text coinValue1 = new Text("+ " + coin2);
        coinValue1.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
        coinValue1.setStyle("-fx-fill: #f6b93b;");

        HBox coinBox1 = new HBox(5, coinImage, coinValue1);
        coinBox1.setAlignment(Pos.CENTER);

        VBox centerBox = new VBox(10, starsBox, formContainer, coinBox1);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.setPadding(new Insets(20));

        Button okButton = new Button("\t  History\t\t");
        okButton.setStyle("-fx-background-color: #fdf58e;-fx-border-color:#f59eb7;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-text-fill: #3c6ca8;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 20");
        try {
            addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }

        okButton.setOnAction(e -> System.out.println("Name: " ));
        HBox buttonBox = new HBox(okButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20, 0, 20, 0));
        base.getChildren().addAll(formFields,centerBox);


        vbox.getChildren().addAll(headerBox,base,buttonBox);
        root.setCenter(vbox);
        okButton.setOnAction(e->{new game_history().start(new Stage());
        stage11.close();});


        Scene scene = new Scene(root,800,650);
        stage11.initStyle(StageStyle.UNDECORATED);
        stage11.setMaximized(true);
        stage11.setScene(scene);
        stage11.show();
    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }
    private void addStars(HBox starsBox,int score) {
        starsBox.getChildren().clear();
        int starCount = 0;

        if (score > 7) {
            starCount = 3;
        } else if (score > 5) {
            starCount = 2;
        } else if (score > 0) {
            starCount = 1;
        }

        for (int i = 0; i < starCount; i++) {
            ImageView star = new ImageView(new Image(getClass().getResource("/com/example/mind_marathon_project/star.png").toExternalForm()));
            star.setFitWidth(50);
            star.setFitHeight(50);
            starsBox.getChildren().add(star);
        }
    }

    private void setTrophyImage(ImageView trophyImage, int score) {
        if (score == 0) {
            trophyImage.setImage(new Image(getClass().getResource("/com/example/mind_marathon_project/trophy.png").toExternalForm()));
        } else {
            trophyImage.setImage(new Image(getClass().getResource("/com/example/mind_marathon_project/trophy.png").toExternalForm()));
        }
    }

    private int calculateCoins(int score) {
        return score; // Coins are equal to the score for simplicity
    }
    public static void main(String[] args) {
        launch();
    }
}