package com.example.mind_marathon_project;

import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;


public class lossResult_page extends Application {

    public void start(Stage stage2) throws Exception {
        CustomTitleBar customTitleBar = new CustomTitleBar(stage2);
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fdeaea;");
        root.setTop(customTitleBar);

        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: #fdccec;" +
                "-fx-background-radius: 20px; " +
                "-fx-border-radius: 20px; " +
                "-fx-border-color: #ffb9e7; " +
                "-fx-padding: 20px;");
        vbox.setMaxWidth(400);
        vbox.setMaxHeight(500);

        ImageView login;
        try {
            login = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/login.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/login.png", e);
        }
        login.setFitWidth(170);
        login.setFitHeight(90);

        StackPane formContainer = new StackPane();
        formContainer.setAlignment(Pos.CENTER);

        ImageView login_image;
        try {
            login_image = new ImageView(new Image(getClass().getResourceAsStream("/com/example/mind_marathon_project/log_pic.png")));
        } catch (NullPointerException e) {
            throw new RuntimeException("Image not found: /com/example/mind_marathon_project/log_pic.png", e);
        }
        login_image.setFitWidth(350);
        login_image.setFitHeight(350);

        VBox formFields = new VBox(40);
        formFields.setAlignment(Pos.CENTER);
        formFields.setPadding(new Insets(10));

        TextField nameField = new TextField();
        nameField.setMaxWidth(150);
        nameField.setMinHeight(40);
        nameField.setPromptText("\tEnter your name");
        nameField.setStyle("-fx-background-color:  #fdccec;-fx-background-radius: 20px;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-prompt-text-fill: #675c6e;-fx-border-color: #FF7BACFF;-fx-text-fill: #ff7bac;-fx-font-weight: bold;-fx-font-family: Calibri;-fx-padding: 5px;-fx-font-size:14px; ");

        Slider ageSlider = new Slider();
        ageSlider.setMin(1);
        ageSlider.setMax(60);
        // ageSlider.setPrefSize(40,50);
        ageSlider.setPrefWidth(80); // Reduce the width
        ageSlider.setPrefHeight(5);
        Label agename = new Label("Age:");
        agename.setStyle("-fx-text-fill: #606060; -fx-font-size: 14px;");
        Label ageLabel = new Label("0");
        ageLabel.setStyle("-fx-text-fill: #ff7bac; -fx-font-size: 14px;");
        ageSlider.setStyle(
                "-fx-control-inner-background: #ffd1dc ;" +   // Track color
                        "-fx-background-color: transparent;" +      // Background
                        "-fx-border-color: transparent;" +         // Remove border
                        "-fx-base: #ff7bac;" // Thumb color
        );
        ageSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            ageLabel.setText(String.valueOf(newVal.intValue()));
        });
        HBox ageContainer = new HBox(10, ageSlider,agename, ageLabel);
        ageContainer.setAlignment(Pos.CENTER);

        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(150);
        passwordField.setMinHeight(40);
        passwordField.setPromptText("  Enter your password");
        passwordField.setStyle("-fx-background-color: #fdccec;-fx-prompt-text-fill: #675c6e;" +
                "-fx-border-color: #FF7BACFF; " +
                "-fx-border-radius: 20px;-fx-border-width: 2px;" +
                "-fx-background-radius: 20px; " +
                "-fx-padding: 5px; " +
                "-fx-font-size: 14px;-fx-text-fill: #ff7bac;-fx-font-weight: bold;-fx-font-family: Calibri;");

        // Add form fields to the container
        formFields.getChildren().addAll(nameField,ageContainer,passwordField);
        formContainer.getChildren().addAll(login_image, formFields);


        Button okButton = new Button("OK");
        okButton.setStyle("-fx-background-color: #fff4f4;-fx-border-color:#FF7BACFF;-fx-border-width: 2px;-fx-border-radius: 20px;-fx-text-fill: #ff7bac;-fx-background-radius: 20px;-fx-font-family: Calibri;-fx-font-weight:bold;-fx-font-size: 18px;-fx-padding: 10 20");
        try {
            addButtonEffects(okButton, "/com/example/mind_marathon_project/main_button.mp3");
        }
        catch (NullPointerException e) {
            throw new RuntimeException( e);
        }
        okButton.setOnAction(e -> System.out.println("Name: " + nameField.getText() +
                ", Age: " + ageLabel.getText() +
                ", Password: " + passwordField.getText()));

        vbox.getChildren().addAll(login,formContainer,okButton);
        root.setCenter(vbox);

        Scene scene = new Scene(root,800,600);
        stage2.initStyle(StageStyle.UNDECORATED);
        stage2.setScene(scene);
        stage2.show();
    }
    private void addButtonEffects(Button button, String soundFile) {
        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), button);
        scaleTransition.setFromX(1.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToX(1.1);
        scaleTransition.setToY(1.1);

        button.setOnMouseEntered(e -> scaleTransition.playFromStart());
        button.setOnMouseExited(e -> {
            scaleTransition.stop();
            button.setScaleX(1.0);
            button.setScaleY(1.0);
        });
    }
    public static void main(String[] args) {
        launch();
    }
}

